export class User
{
username:string;
}